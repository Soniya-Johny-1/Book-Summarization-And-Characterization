# Book-Summarization-And-Characterization
Desktop platform, where user can get the summary as well as the profile of main characters of the desired book. Summary will include paraphrasing sections of source document which is closer to what a human might express.

Platform : Python, PyQT, NLTK
